import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-optionlist',
  templateUrl: './optionlist.page.html',
  styleUrls: ['./optionlist.page.scss'],
})
export class OptionlistPage implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  locationDetails(){
   this.router.navigate(['home']);
  }

  prevpage(){
    this.router.navigate(['firstpage'])
  }


}
